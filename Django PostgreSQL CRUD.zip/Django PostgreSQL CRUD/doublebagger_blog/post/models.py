from django.db import models
# Create your models here.
class post(models.Model):
 title = models.CharField(max_length=100)
 slug  = models.SlugField(max_length=50, unique_for_month='pub_date')
 text  = models.TextField()
 pub_date = models.DateField('date_publishesd', auto_now_add=True)

class company(models.Model):
 name = models.CharField(max_length=100, db_index=True)
 slug = models.SlugField(max_length=50, unique=True)
 description = models.TextField()
 pe_ratio = models.DecimalField(max_digits=7, decimal_places=2)